# FlagOS Open Computing Global Challenge (Season 2) Submission
## Portable High-Throughput FlagGems Triton Operators (`add_rms_norm_v2`, `strided_silu_and_mul`, `chunked_online_log_softmax`)

- **Competition**: `kaggle:flag-os-open-computing-global-challenge-season-2` (`$14,925 USD`)
- **6-Dimension Alignment**:
  1. **Functional Correctness**: Verified across `fp32`, `bf16`, `fp16`, non-contiguous views, `inplace_residual=True/False`, `0`-row empty tensors, prime widths (`1536`, `5123`, `33331`), and `130,560`/`151,936` vocabularies with 64-bit (`tl.int64`) pointer arithmetic.
  2. **Performance Competitiveness**: Eliminates non-contiguous N-D index overhead on sliced `[T, 2*D]` SwiGLU inputs and eliminates `[B, V]` FP32 HBM materialization on 130K+ vocab `log_softmax`.
  3. **Open-Source Adaptability & Cross-Platform Compatibility**: Pure Triton `tl.*` intrinsics (`0` vendor-locked PTX).

### Reproduction
```bash
pip install torch triton
python3 src/flaggems_s2_operators.py --work-dir ./out --no-auto-disconnect
```
