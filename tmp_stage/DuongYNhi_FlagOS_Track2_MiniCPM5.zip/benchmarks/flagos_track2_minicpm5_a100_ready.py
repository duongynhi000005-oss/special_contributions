#!/usr/bin/env python3
"""
Turnkey Zero-Idle Colab Pro+ A100 Profiler, Baseline-vs-Patched E2E vLLM Benchmark,
MATH-500 (>= 0.95) Accuracy Retention Gate, & Submission Packager for:
  FlagOS Open Computing Global Challenge – Track 2 ($9,000 USD, ONLY 2 teams!)
  Competition Slug: kaggle:flag-os-open-computing-global-challenge-track-2
  Target Model: openbmb/MiniCPM5-2B (bfloat16, NO quantization, NO speculative decoding)

Pipeline Stages:
  1. Correctness Gate (`torch.testing.assert_close`): Verifies `fused_inplace_add_rms_norm`,
     `fused_gate_up_silu_and_mul`, and `fused_strided_gqa_rope` across fp16, bf16, fp32 on exact
     MiniCPM5-2B dimensions (hidden=2048, inter=6144, 16:2 GQA, head_dim=128).
  2. Kernel Microbenchmark (`triton.testing.do_bench`): Measures latency (ms), effective GB/s,
     and speedup vs PyTorch ATen across decode (T=1, 32, 128) & prefill (T=4096, 16384) workloads.
  3. End-to-End `openbmb/MiniCPM5-2B` Baseline vs Patched vLLM Throughput & `MATH-500` Gate:
     - Installs `vllm`, `flag-gems`, `datasets`, `transformers` (+ optional `vllm-plugin-FL`).
     - Injects child-worker hooks into spawned `vllm` CLI + `EngineCore` subprocesses via generated
       `patch_site/sitecustomize.py` (`PYTHONPATH` gated by `FLAGOS_PATCH_ENABLE=0` vs `1`) and
       verifies `patched_kernel_hits > 0` from child worker hit logs!
     - Measures real `tokens/s` speedup (`FLAGOS_PATCH_ENABLE=1` vs `0`) on `4k` (4096/1024) and
       `16k` (16384/1024) scenarios, and enforces `HuggingFaceH4/MATH-500` greedy accuracy retention
       `>= 0.95` (`0` quantization, `0` speculative decoding).
  4. Submission Archive Builder: Packages `DuongYNhi_FlagOS_Track2_MiniCPM5.zip` containing
     `src/`, `benchmarks/`, `readme.md`, and `report.md`, uploads to HF private repo, and calls
     `google.colab.runtime.unassign()` inside `finally:` (Rule 95).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

try:
    import torch
except ImportError:
    torch = None  # type: ignore

from flaggems_minicpm5_kernels import (
    HAS_TRITON,
    MINICPM5_2B_SPEC,
    fused_gate_up_silu_and_mul,
    fused_inplace_add_rms_norm,
    fused_strided_gqa_rope,
    ref_add_rms_norm,
    ref_gate_up_silu_and_mul,
    ref_neox_gqa_rope,
)

DEFAULT_HF_BUNDLE_REPO = "duongynhi18/flagos-challenge-bundles"
MATH500_MIN_RETENTION = 0.95


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def log(msg: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts} UTC] [FlagOS-T2] {msg}", flush=True)


def load_runtime_hf_token() -> str:
    for key in ("HF_TOKEN", "HUGGINGFACE_TOKEN", "HUGGINGFACE_HUB_TOKEN"):
        v = os.environ.get(key, "").strip()
        if v:
            return v
    try:
        from google.colab import userdata  # type: ignore
        for key in ("HF_TOKEN", "HUGGINGFACE_TOKEN"):
            try:
                v = (userdata.get(key) or "").strip()
                if v:
                    os.environ["HF_TOKEN"] = v
                    return v
            except Exception:
                continue
    except ImportError:
        pass
    return ""


def disconnect_colab_zero_idle(enable: bool = True) -> None:
    if not enable:
        return
    try:
        from google.colab import runtime  # type: ignore
        log("Rule 95 Zero-Idle Gate: Calling google.colab.runtime.unassign() immediately...")
        runtime.unassign()
    except ImportError:
        log("Not running inside Google Colab; skipping runtime.unassign().")
    except Exception as exc:
        log(f"Warning: runtime.unassign() raised {type(exc).__name__}: {exc}")


# ---------------------------------------------------------------------------
# Child-Worker `sitecustomize.py` Patch Injector & Hit-Log Aggregator
# ---------------------------------------------------------------------------

def write_child_patch_site(work_dir: Path, kernel_dir: Path) -> Path:
    """
    Materialize `patch_site/sitecustomize.py` so every spawned `vllm` CLI and `EngineCore`
    worker subprocess automatically installs our Triton layer hooks when `FLAGOS_PATCH_ENABLE=1`.
    """
    patch_site = (work_dir / "patch_site").resolve()
    patch_site.mkdir(parents=True, exist_ok=True)
    kdir_str = str(kernel_dir.resolve())
    site_code = (
        "import os, sys\n"
        "if os.environ.get('FLAGOS_PATCH_ENABLE') == '1':\n"
        f"    _kdir = {kdir_str!r}\n"
        "    if _kdir not in sys.path:\n"
        "        sys.path.insert(0, _kdir)\n"
        "    import flaggems_minicpm5_kernels as _fgk\n"
        "    _fgk.install_auto_patch_import_hook()\n"
    )
    (patch_site / "sitecustomize.py").write_text(site_code, encoding="utf-8")
    return patch_site


def build_child_env(
    patch_site: Path,
    kernel_dir: Path,
    enable_patch: bool,
    hit_log_dir: Optional[Path] = None,
) -> Dict[str, str]:
    env = dict(os.environ)
    py_parts = [str(patch_site.resolve()), str(kernel_dir.resolve())]
    existing = env.get("PYTHONPATH", "").strip()
    if existing:
        py_parts.append(existing)
    env["PYTHONPATH"] = os.pathsep.join(py_parts)
    env["FLAGOS_PATCH_ENABLE"] = "1" if enable_patch else "0"
    if hit_log_dir is not None:
        env["FLAGOS_HIT_LOG_DIR"] = str(hit_log_dir.resolve())
    else:
        env.pop("FLAGOS_HIT_LOG_DIR", None)
    return env


def aggregate_child_hit_logs(hit_log_dir: Path) -> Dict[str, Any]:
    total_hits = 0
    by_op: Dict[str, int] = {"rms_norm": 0, "silu_and_mul": 0, "rotary": 0}
    worker_pids: List[int] = []
    backends: set[str] = set()
    if hit_log_dir.is_dir():
        for fp in sorted(hit_log_dir.glob("hit_*.json")):
            try:
                d = json.loads(fp.read_text("utf-8"))
                worker_pids.append(int(d.get("pid", 0)))
                total_hits += int(d.get("total_hits", 0))
                for k, v in (d.get("hits") or {}).items():
                    by_op[k] = by_op.get(k, 0) + int(v)
                for b in d.get("backends") or []:
                    backends.add(str(b))
            except Exception:
                continue
    return {
        "total_hits": total_hits,
        "by_op": by_op,
        "worker_pids": worker_pids,
        "backends": sorted(backends),
    }


# ---------------------------------------------------------------------------
# Deterministic MATH-500 Answer Parser & Retention Gate (`>= 0.95`)
# ---------------------------------------------------------------------------

def extract_boxed_or_final_answer(text: str) -> str:
    """Extract final `\\boxed{...}` (handling nested braces) or trailing numeric/algebraic answer."""
    s = text or ""
    idx = s.rfind("\\boxed{")
    if idx != -1:
        depth = 0
        start = idx + len("\\boxed{")
        for pos in range(start, len(s)):
            ch = s[pos]
            if ch == "{":
                depth += 1
            elif ch == "}":
                if depth == 0:
                    return s[start:pos].strip()
                depth -= 1
    m = re.findall(r"(?:final answer is|answer:)\s*([^\n.]+)", s, flags=re.IGNORECASE)
    if m:
        return m[-1].strip()
    nums = re.findall(r"-?\d+(?:/\d+|\.\d+)?", s)
    return nums[-1] if nums else s.strip()[-64:]


def normalize_math_answer(ans: str) -> str:
    s = (ans or "").strip()
    s = s.replace("\\left", "").replace("\\right", "").replace("\\$", "").replace("$", "")
    s = re.sub(r"\\text\{([^}]*)\}", r"\1", s)
    s = re.sub(r"\\mathrm\{([^}]*)\}", r"\1", s)
    s = re.sub(r"\\dfrac", r"\\frac", s)
    s = re.sub(r"\s+", "", s)
    return s.rstrip(".")


def evaluate_math500_retention(
    gold_answers: Sequence[str],
    baseline_outputs: Sequence[str],
    patched_outputs: Sequence[str],
    min_retention: float = MATH500_MIN_RETENTION,
) -> Dict[str, Any]:
    if not (len(gold_answers) == len(baseline_outputs) == len(patched_outputs)) or not gold_answers:
        raise ValueError("Mismatched or empty MATH-500 evaluation lists")

    n = len(gold_answers)
    base_correct = 0
    patch_correct = 0
    exact_pred_match = 0
    for g_raw, b_raw, p_raw in zip(gold_answers, baseline_outputs, patched_outputs):
        g = normalize_math_answer(g_raw)
        b = normalize_math_answer(extract_boxed_or_final_answer(b_raw))
        p = normalize_math_answer(extract_boxed_or_final_answer(p_raw))
        if b == g:
            base_correct += 1
        if p == g:
            patch_correct += 1
        if b == p:
            exact_pred_match += 1

    base_acc = base_correct / n
    patch_acc = patch_correct / n
    pred_agreement = exact_pred_match / n
    retention = (patch_acc / base_acc) if base_acc > 0 else pred_agreement
    passed = retention >= min_retention
    return {
        "num_problems": n,
        "baseline_correct": base_correct,
        "patched_correct": patch_correct,
        "baseline_acc": round(base_acc, 4),
        "patched_acc": round(patch_acc, 4),
        "accuracy_retention": round(retention, 4),
        "prediction_agreement": round(pred_agreement, 4),
        "min_retention_threshold": min_retention,
        "passed": passed,
    }


def extract_vllm_throughput_tok_s(bench_json: Dict[str, Any]) -> float:
    for key in ("tokens_per_second", "total_token_throughput", "output_throughput"):
        if bench_json.get(key) is not None:
            return float(bench_json[key])
    total_toks = bench_json.get("total_num_tokens")
    elapsed = bench_json.get("elapsed_time")
    if total_toks and elapsed and float(elapsed) > 0:
        return float(total_toks) / float(elapsed)
    return 0.0


# ---------------------------------------------------------------------------
# Stage 1 & 2: Correctness Suite + Triton `do_bench` Microbenchmarks
# ---------------------------------------------------------------------------

def run_correctness_suite(device: str) -> List[Dict[str, Any]]:
    """Verify exact numerical match against reference PyTorch on MiniCPM5-2B shapes."""
    torch.manual_seed(42)
    dtypes = [torch.float32, torch.bfloat16]
    if device == "cuda":
        dtypes.append(torch.float16)

    results: List[Dict[str, Any]] = []
    hidden = MINICPM5_2B_SPEC["hidden_size"]
    inter = MINICPM5_2B_SPEC["intermediate_size"]
    hq = MINICPM5_2B_SPEC["num_attention_heads"]
    hk = MINICPM5_2B_SPEC["num_key_value_heads"]
    hd = MINICPM5_2B_SPEC["head_dim"]

    for dt in dtypes:
        tol = 1.5e-2 if dt in (torch.bfloat16, torch.float16) else 1e-5
        for n_tokens in (1, 37, 512):
            # 1) Fused In-Place Add + RMSNorm
            x = torch.randn((n_tokens, hidden), device=device, dtype=dt)
            res0 = torch.randn((n_tokens, hidden), device=device, dtype=dt)
            w = torch.randn((hidden,), device=device, dtype=dt)

            ref_y, ref_r = ref_add_rms_norm(x, res0.clone(), w, 1e-6)
            res_live = res0.clone()
            got_y, got_r = fused_inplace_add_rms_norm(x, res_live, w, 1e-6)  # type: ignore[misc]
            torch.testing.assert_close(got_y, ref_y, rtol=tol, atol=tol)
            torch.testing.assert_close(got_r, ref_r, rtol=tol, atol=tol)

            # 2) Fused Gate-Up SwiGLU
            gu = torch.randn((n_tokens, 2 * inter), device=device, dtype=dt)
            ref_act = ref_gate_up_silu_and_mul(gu)
            got_act = fused_gate_up_silu_and_mul(gu)
            torch.testing.assert_close(got_act, ref_act, rtol=tol, atol=tol)

            # 3) Fused Asymmetric 16:2 GQA NeoX RoPE (both power-of-two hd=128 & non-pot hd=96 fallback)
            q = torch.randn((n_tokens, hq, hd), device=device, dtype=dt)
            k = torch.randn((n_tokens, hk, hd), device=device, dtype=dt)
            cos = torch.randn((n_tokens + 16, hd // 2), device=device, dtype=dt)
            sin = torch.randn((n_tokens + 16, hd // 2), device=device, dtype=dt)
            pos = torch.arange(n_tokens, device=device, dtype=torch.int64)

            rq, rk = ref_neox_gqa_rope(q.clone(), k.clone(), cos, sin, pos)  # type: ignore[misc]
            q_inp, k_inp = q.clone(), k.clone()
            gq, gk = fused_strided_gqa_rope(q_inp, k_inp, cos, sin, pos, inplace=True)  # type: ignore[misc]
            torch.testing.assert_close(gq, rq, rtol=tol, atol=tol)
            torch.testing.assert_close(gk, rk, rtol=tol, atol=tol)
            torch.testing.assert_close(q_inp, rq, rtol=tol, atol=tol)
            torch.testing.assert_close(k_inp, rk, rtol=tol, atol=tol)

            # Non-power-of-two head_dim=96 (`half_d=48`) inplace fallback check
            q96 = torch.randn((n_tokens, hq, 96), device=device, dtype=dt)
            k96 = torch.randn((n_tokens, hk, 96), device=device, dtype=dt)
            c48 = torch.randn((n_tokens + 8, 48), device=device, dtype=dt)
            s48 = torch.randn((n_tokens + 8, 48), device=device, dtype=dt)
            rq96, rk96 = ref_neox_gqa_rope(q96.clone(), k96.clone(), c48, s48, pos)  # type: ignore[misc]
            fused_strided_gqa_rope(q96, k96, c48, s48, pos, inplace=True)
            torch.testing.assert_close(q96, rq96, rtol=tol, atol=tol)
            torch.testing.assert_close(k96, rk96, rtol=tol, atol=tol)

        results.append({"dtype": str(dt), "device": device, "status": "PASS"})
    return results


def run_cuda_kernel_benchmarks() -> List[Dict[str, Any]]:
    """Measure real hardware latency & HBM bandwidth on A100 using triton.testing.do_bench."""
    if not (torch is not None and torch.cuda.is_available() and HAS_TRITON):
        return []
    import triton.testing  # type: ignore

    hidden = MINICPM5_2B_SPEC["hidden_size"]
    inter = MINICPM5_2B_SPEC["intermediate_size"]
    hq = MINICPM5_2B_SPEC["num_attention_heads"]
    hk = MINICPM5_2B_SPEC["num_key_value_heads"]
    hd = MINICPM5_2B_SPEC["head_dim"]
    dt = torch.bfloat16
    rows: List[Dict[str, Any]] = []

    for n_tokens in (1, 32, 128, 4096, 16384):
        x = torch.randn((n_tokens, hidden), device="cuda", dtype=dt)
        r = torch.randn((n_tokens, hidden), device="cuda", dtype=dt)
        w = torch.randn((hidden,), device="cuda", dtype=dt)

        ms_ref = triton.testing.do_bench(lambda: ref_add_rms_norm(x, r, w, 1e-6), warmup=25, rep=100)
        ms_tri = triton.testing.do_bench(lambda: fused_inplace_add_rms_norm(x, r, w, 1e-6), warmup=25, rep=100)
        bytes_moved = n_tokens * hidden * 2 * 4
        gbps = (bytes_moved / 1e9) / (ms_tri / 1e3)
        rows.append({
            "op": "fused_inplace_add_rms_norm",
            "tokens": n_tokens,
            "pytorch_ms": round(ms_ref, 5),
            "triton_ms": round(ms_tri, 5),
            "speedup_x": round(ms_ref / max(ms_tri, 1e-6), 3),
            "effective_gbps": round(gbps, 2),
        })

        gu = torch.randn((n_tokens, 2 * inter), device="cuda", dtype=dt)
        ms_ref_act = triton.testing.do_bench(lambda: ref_gate_up_silu_and_mul(gu), warmup=25, rep=100)
        ms_tri_act = triton.testing.do_bench(lambda: fused_gate_up_silu_and_mul(gu), warmup=25, rep=100)
        bytes_act = n_tokens * (3 * inter) * 2
        rows.append({
            "op": "fused_gate_up_silu_and_mul",
            "tokens": n_tokens,
            "pytorch_ms": round(ms_ref_act, 5),
            "triton_ms": round(ms_tri_act, 5),
            "speedup_x": round(ms_ref_act / max(ms_tri_act, 1e-6), 3),
            "effective_gbps": round((bytes_act / 1e9) / (ms_tri_act / 1e3), 2),
        })

        q = torch.randn((n_tokens, hq, hd), device="cuda", dtype=dt)
        k = torch.randn((n_tokens, hk, hd), device="cuda", dtype=dt)
        cos = torch.randn((n_tokens + 8, hd // 2), device="cuda", dtype=dt)
        sin = torch.randn((n_tokens + 8, hd // 2), device="cuda", dtype=dt)
        pos = torch.arange(n_tokens, device="cuda", dtype=torch.int64)
        ms_ref_rope = triton.testing.do_bench(lambda: ref_neox_gqa_rope(q, k, cos, sin, pos), warmup=25, rep=100)
        ms_tri_rope = triton.testing.do_bench(
            lambda: fused_strided_gqa_rope(q, k, cos, sin, pos, inplace=True), warmup=25, rep=100
        )
        rows.append({
            "op": "fused_strided_gqa_rope_16x2",
            "tokens": n_tokens,
            "pytorch_ms": round(ms_ref_rope, 5),
            "triton_ms": round(ms_tri_rope, 5),
            "speedup_x": round(ms_ref_rope / max(ms_tri_rope, 1e-6), 3),
        })
    return rows


# ---------------------------------------------------------------------------
# Stage 3: Baseline vs Patched vLLM E2E Benchmark + MATH-500 Parity Gate
# ---------------------------------------------------------------------------

def run_math500_child_eval(
    work_dir: Path,
    patch_site: Path,
    kernel_dir: Path,
    num_samples: int = 100,
) -> Dict[str, Any]:
    """
    Run deterministic greedy `HuggingFaceH4/MATH-500` evaluation in isolated Baseline (`0`) vs
    Patched (`1`) child processes (`bfloat16`, `0` quantization, `0` speculative decoding)
    and enforce `accuracy_retention >= 0.95`.
    """
    eval_dir = work_dir / "math500_eval"
    eval_dir.mkdir(parents=True, exist_ok=True)
    child_script = eval_dir / "_run_math500_worker.py"
    child_script.write_text(
        "import json, sys\n"
        "from datasets import load_dataset\n"
        "from vllm import LLM, SamplingParams\n"
        "model_id, n_lim, out_path = sys.argv[1], int(sys.argv[2]), sys.argv[3]\n"
        "ds = load_dataset('HuggingFaceH4/MATH-500', split='test')\n"
        "if n_lim > 0 and n_lim < len(ds):\n"
        "    ds = ds.select(range(n_lim))\n"
        "prompts = [\n"
        "    f'Solve the following math problem step by step and put your final answer inside \\\\boxed{{}}.\\n\\n{row[\"problem\"]}'\n"
        "    for row in ds\n"
        "]\n"
        "golds = [str(row['answer']) for row in ds]\n"
        "llm = LLM(model=model_id, dtype='bfloat16', trust_remote_code=True, max_model_len=4096, gpu_memory_utilization=0.88)\n"
        "sp = SamplingParams(temperature=0.0, max_tokens=1024)\n"
        "outs = llm.generate(prompts, sp)\n"
        "texts = [o.outputs[0].text for o in outs]\n"
        "with open(out_path, 'w', encoding='utf-8') as f:\n"
        "    json.dump({'golds': golds, 'outputs': texts}, f)\n",
        encoding="utf-8",
    )

    base_json = eval_dir / "math500_baseline.json"
    patch_json = eval_dir / "math500_patched.json"
    hit_dir = eval_dir / "math500_hits"
    if hit_dir.exists():
        shutil.rmtree(hit_dir)
    hit_dir.mkdir(parents=True, exist_ok=True)

    env_base = build_child_env(patch_site, kernel_dir, enable_patch=False)
    env_patch = build_child_env(patch_site, kernel_dir, enable_patch=True, hit_log_dir=hit_dir)

    log(f"Running MATH-500 Baseline (FLAGOS_PATCH_ENABLE=0, n={num_samples})...")
    subprocess.run(
        [sys.executable, str(child_script), MINICPM5_2B_SPEC["model_id"], str(num_samples), str(base_json)],
        env=env_base,
        check=True,
    )
    log(f"Running MATH-500 Patched (FLAGOS_PATCH_ENABLE=1, n={num_samples})...")
    subprocess.run(
        [sys.executable, str(child_script), MINICPM5_2B_SPEC["model_id"], str(num_samples), str(patch_json)],
        env=env_patch,
        check=True,
    )

    b_data = json.loads(base_json.read_text("utf-8"))
    p_data = json.loads(patch_json.read_text("utf-8"))
    hit_summary = aggregate_child_hit_logs(hit_dir)
    if hit_summary["total_hits"] <= 0:
        raise RuntimeError("Patched MATH-500 worker recorded 0 Triton kernel hits — child patch did not fire!")

    gate = evaluate_math500_retention(b_data["golds"], b_data["outputs"], p_data["outputs"])
    gate["patched_kernel_hits"] = hit_summary
    if not gate["passed"]:
        raise RuntimeError(
            f"MATH-500 retention gate FAILED: retention={gate['accuracy_retention']} < {MATH500_MIN_RETENTION}"
        )
    log(f"MATH-500 Gate PASS: retention={gate['accuracy_retention']} (hits={hit_summary['total_hits']})")
    return gate


def run_minicpm5_e2e_vllm_benchmark(
    work_dir: Path,
    run_e2e: bool,
    math500_samples: int = 100,
) -> Dict[str, Any]:
    """
    Run end-to-end `openbmb/MiniCPM5-2B` bfloat16 Baseline (`FLAGOS_PATCH_ENABLE=0`) vs Patched
    (`FLAGOS_PATCH_ENABLE=1`) throughput benchmark (`4k` & `16k`) + `MATH-500 >= 0.95` gate.
    """
    kernel_dir = Path(__file__).resolve().parent
    patch_site = write_child_patch_site(work_dir, kernel_dir)

    if not (run_e2e and torch is not None and torch.cuda.is_available()):
        return {
            "executed": False,
            "patch_site": str(patch_site),
            "reason": "CPU build/test mode or --skip-e2e-vllm set",
        }

    log("Installing vLLM + flag-gems + datasets + transformers for MiniCPM5-2B E2E benchmark...")
    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "-q",
            "--upgrade",
            "vllm",
            "flag-gems",
            "datasets",
            "huggingface_hub",
            "transformers",
        ],
        check=True,
    )
    # Optional vllm-plugin-FL install (non-fatal if upstream git branch pins older vLLM)
    vllm_fl_rc = subprocess.call(
        [sys.executable, "-m", "pip", "install", "-q", "--no-deps", "git+https://github.com/flagos-ai/vllm-plugin-FL.git"]
    )

    out_dir = work_dir / "vllm_bench_out"
    out_dir.mkdir(parents=True, exist_ok=True)
    scenarios = [
        ("4k_scenario", 4096, 1024, 64),
        ("16k_scenario", 16384, 1024, 32),
    ]
    scenario_metrics: Dict[str, Any] = {}

    for name, in_len, out_len, n_prompts in scenarios:
        pair_res: Dict[str, Any] = {}
        for mode_label, enable_patch in (("baseline", False), ("patched", True)):
            out_json = out_dir / f"minicpm5_{name}_{mode_label}.json"
            hit_dir = out_dir / f"hits_{name}" if enable_patch else None
            if hit_dir is not None:
                if hit_dir.exists():
                    shutil.rmtree(hit_dir)
                hit_dir.mkdir(parents=True, exist_ok=True)

            env = build_child_env(patch_site, kernel_dir, enable_patch=enable_patch, hit_log_dir=hit_dir)
            cmd = [
                "vllm",
                "bench",
                "throughput",
                "--model",
                MINICPM5_2B_SPEC["model_id"],
                "--dtype",
                "bfloat16",
                "--trust-remote-code",
                "--dataset-name",
                "random",
                "--input-len",
                str(in_len),
                "--output-len",
                str(out_len),
                "--num-prompts",
                str(n_prompts),
                "--output-json",
                str(out_json),
            ]
            t0 = time.time()
            rc = subprocess.call(cmd, env=env)
            elapsed = round(time.time() - t0, 2)
            if rc == 0 and out_json.is_file():
                raw_j = json.loads(out_json.read_text("utf-8"))
                raw_j["tokens_per_second_resolved"] = round(extract_vllm_throughput_tok_s(raw_j), 3)
                if hit_dir is not None:
                    hits = aggregate_child_hit_logs(hit_dir)
                    raw_j["patched_kernel_hits"] = hits
                    if hits["total_hits"] <= 0:
                        raise RuntimeError(f"Patched benchmark {name} had 0 child kernel hits!")
                pair_res[mode_label] = raw_j
            else:
                pair_res[mode_label] = {"rc": rc, "elapsed_s": elapsed}

        base_tps = float((pair_res.get("baseline") or {}).get("tokens_per_second_resolved") or 0.0)
        patch_tps = float((pair_res.get("patched") or {}).get("tokens_per_second_resolved") or 0.0)
        if base_tps > 0 and patch_tps > 0:
            pair_res["throughput_speedup_x"] = round(patch_tps / base_tps, 4)
        scenario_metrics[name] = pair_res

    math500_gate = run_math500_child_eval(work_dir, patch_site, kernel_dir, num_samples=math500_samples)
    return {
        "executed": True,
        "vllm_plugin_fl_pip_rc": vllm_fl_rc,
        "child_patch_site": str(patch_site),
        "precision": "bfloat16 (0 quantization, 0 speculative decoding)",
        "scenarios": scenario_metrics,
        "math500_accuracy_gate": math500_gate,
    }


def build_submission_archive(work_dir: Path, bench_summary: Dict[str, Any]) -> Dict[str, Any]:
    """Build official FlagOS Track 2 submission zip (`DuongYNhi_FlagOS_Track2_MiniCPM5.zip`)."""
    here = Path(__file__).resolve().parent
    kernel_src = (here / "flaggems_minicpm5_kernels.py").read_text("utf-8")
    runner_src = Path(__file__).resolve().read_text("utf-8")
    patch_site = write_child_patch_site(work_dir, here)
    sitecustomize_src = (patch_site / "sitecustomize.py").read_text("utf-8")

    readme_md = """# FlagOS Open Computing Global Challenge — Track 2 Submission
## MiniCPM5-2B Full-Stack Inference Throughput Optimization (`bfloat16`)

### 1. Overview & Compliance
- **Target Model**: `openbmb/MiniCPM5-2B` (`LlamaForCausalLM`, `42` layers, `hidden_size=2048`, `intermediate_size=6144`, `16:2` GQA, `head_dim=128`, `rope_theta=5,000,000`, `vocab_size=130,560`)
- **Fairness Compliance**: Strict `bfloat16` full precision (**NO** quantization, **NO** speculative decoding, **NO** benchmark script tampering), enforcing `HuggingFaceH4/MATH-500 >= 0.95` greedy accuracy retention.
- **Cross-Chip Portability**: Pure 64-bit (`tl.int64` pointer-safe) Triton kernels (`0` vendor-locked PTX inline assembly), portable across NVIDIA A100, **Iluvatar CoreX BI-V150 (64GB)**, and **MetaX Xiyun C500 (64GB)** via `FlagGems`, `vllm-plugin-FL`, and native `vLLM` child-worker `sitecustomize.py` injection.

### 2. Core Kernel & Child-Worker Dispatch Optimizations
1. **`fused_inplace_add_rms_norm`**: Eliminates separate residual-addition HBM traffic across all 84 norm sites per token while matching exact vLLM BF16 weight-multiply rounding `(x * rrms).to(bf16) * weight`.
2. **`fused_gate_up_silu_and_mul`**: Coalesced single-tensor `[T, 12288]` autotuned SwiGLU kernel eliminating non-contiguous slice stride overhead.
3. **`fused_strided_gqa_rope`**: Single-launch asymmetric `16:2` GQA NeoX RoPE kernel eliminating 3 `.contiguous()` copies, `torch.arange` allocations, and dummy K launches.
4. **Child-Process `sitecustomize.py` Auto-Hook**: Automatically patches spawned `vllm` CLI and `EngineCore` subprocesses when `FLAGOS_PATCH_ENABLE=1` and records verified per-PID kernel hit counters.

### 3. Reproduction Instructions
```bash
pip install torch triton vllm flag-gems datasets
python3 benchmarks/flagos_track2_minicpm5_a100_ready.py --work-dir ./out --no-auto-disconnect
```
"""

    report_md = (
        "# Technical Report — MiniCPM5-2B Inference Throughput Optimization (FlagOS Track 2)\n\n"
        f"- **Generated UTC**: `{utc_now_iso()}`\n"
        f"- **Device**: `{bench_summary.get('device_name', 'CPU/Preflight')}`\n\n"
        "## Correctness, Throughput & MATH-500 Summary\n"
        "```json\n"
        f"{json.dumps(bench_summary, indent=2)}\n"
        "```\n"
    )

    zip_path = work_dir / "DuongYNhi_FlagOS_Track2_MiniCPM5.zip"
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_zip = zip_path.with_suffix(".zip.tmp")

    files_to_pack = {
        "readme.md": readme_md.encode("utf-8"),
        "report.md": report_md.encode("utf-8"),
        "src/flaggems_minicpm5_kernels.py": kernel_src.encode("utf-8"),
        "src/sitecustomize.py": sitecustomize_src.encode("utf-8"),
        "benchmarks/flagos_track2_minicpm5_a100_ready.py": runner_src.encode("utf-8"),
        "benchmarks/benchmark_summary.json": json.dumps(bench_summary, indent=2).encode("utf-8"),
    }

    with zipfile.ZipFile(tmp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel, payload in sorted(files_to_pack.items()):
            zi = zipfile.ZipInfo(rel, date_time=(2026, 11, 15, 12, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, payload)

    with zipfile.ZipFile(tmp_zip, "r") as zf_chk:
        assert zf_chk.testzip() is None

    os.replace(tmp_zip, zip_path)
    sha256 = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    return {
        "zip_path": str(zip_path),
        "zip_bytes": zip_path.stat().st_size,
        "sha256": sha256,
        "members": sorted(files_to_pack.keys()),
    }


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    here = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description="FlagOS Track 2 MiniCPM5-2B Zero-Idle Colab A100 Pack")
    p.add_argument("--work-dir", default=str(here))
    p.add_argument("--hf-repo", default=DEFAULT_HF_BUNDLE_REPO)
    p.add_argument("--math500-samples", type=int, default=100, help="Number of MATH-500 test problems (0 = all 500)")
    p.add_argument("--skip-e2e-vllm", action="store_true", help="Run kernel correctness+do_bench+zip without full vLLM download")
    p.add_argument("--cpu-verify-only", action="store_true", help="Run CPU numerical verification + package zip")
    p.add_argument("--no-auto-disconnect", action="store_true")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    work_dir = Path(args.work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    try:
        if torch is None:
            raise RuntimeError("PyTorch is required to execute FlagOS Track 2 numerical/GPU verification.")
        use_cuda = torch.cuda.is_available() and not args.cpu_verify_only
        device = "cuda" if use_cuda else "cpu"
        dev_name = torch.cuda.get_device_name(0) if use_cuda else "CPU_REFERENCE_VERIFY"
        log(f"Starting FlagOS Track 2 pipeline on device={device} ({dev_name})")

        correctness = run_correctness_suite(device)
        log(f"Correctness suite PASS across {len(correctness)} dtype configs")

        kernel_bench = run_cuda_kernel_benchmarks() if use_cuda else []
        e2e_bench = run_minicpm5_e2e_vllm_benchmark(
            work_dir,
            run_e2e=(use_cuda and not args.skip_e2e_vllm),
            math500_samples=args.math500_samples,
        )

        summary = {
            "completed_utc": utc_now_iso(),
            "competition": "kaggle:flag-os-open-computing-global-challenge-track-2",
            "model_spec": MINICPM5_2B_SPEC,
            "device": device,
            "device_name": dev_name,
            "correctness": correctness,
            "kernel_benchmarks": kernel_bench,
            "e2e_vllm": e2e_bench,
        }
        archive_meta = build_submission_archive(work_dir, summary)
        summary["submission_archive"] = archive_meta
        summary_path = work_dir / "flagos_track2_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        log(f"Built Track 2 archive: {archive_meta['zip_path']} ({archive_meta['zip_bytes']} B)")

        if use_cuda:
            hf_tok = load_runtime_hf_token()
            if hf_tok:
                from huggingface_hub import HfApi  # type: ignore
                api = HfApi(token=hf_tok)
                api.create_repo(repo_id=args.hf_repo, repo_type="model", private=True, exist_ok=True)
                for fp in (Path(archive_meta["zip_path"]), summary_path):
                    api.upload_file(path_or_fileobj=str(fp), path_in_repo=fp.name, repo_id=args.hf_repo, repo_type="model")
                    log(f"Uploaded {fp.name} -> hf://{args.hf_repo}/{fp.name}")
        return 0
    finally:
        if not args.cpu_verify_only:
            disconnect_colab_zero_idle(enable=not args.no_auto_disconnect)


if __name__ == "__main__":
    raise SystemExit(main())
