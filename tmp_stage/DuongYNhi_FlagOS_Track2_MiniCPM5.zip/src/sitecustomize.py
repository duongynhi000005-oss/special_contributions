import os, sys
if os.environ.get('FLAGOS_PATCH_ENABLE') == '1':
    _kdir = '/content/job_flagos_track2_v3'
    if _kdir not in sys.path:
        sys.path.insert(0, _kdir)
    import flaggems_minicpm5_kernels as _fgk
    _fgk.install_auto_patch_import_hook()
