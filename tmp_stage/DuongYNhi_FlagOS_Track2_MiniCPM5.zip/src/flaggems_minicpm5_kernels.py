#!/usr/bin/env python3
"""
Portable Multi-Chip Triton Kernels & vLLM / vllm-plugin-FL Child-Worker Hooks for:
  FlagOS Open Computing Global Challenge – Track 2 ($9,000 USD, 2 teams)
  Target Model: openbmb/MiniCPM5-2B (bfloat16, 42 layers, hidden=2048, inter=6144,
                16 Q heads : 2 KV heads [8:1 GQA], head_dim=128, rope_theta=5e6, vocab=130560)

Strictly portable Triton (0 NVIDIA-only inline PTX, 64-bit `tl.int64` pointer arithmetic), compatible with:
  - Colab Pro+ NVIDIA A100-SXM4-80GB (CUDA / SM80 benchmarking & autotuning)
  - Official Track 2 evaluation accelerators: Iluvatar CoreX BI-V150 (64GB) & MetaX Xiyun C500 (64GB)
  - Competition fairness rules: Full bfloat16 precision (NO quantization, NO speculative decoding),
    preserving >= 0.95 MATH-500 accuracy retention while eliminating HBM memory-bandwidth bottlenecks.
"""
from __future__ import annotations

import atexit
import importlib.abc
import importlib.machinery
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Set, Tuple, Union

try:
    import torch
except ImportError:
    torch = None  # type: ignore

try:
    import triton
    import triton.language as tl

    HAS_TRITON = True
except ImportError:
    triton = None  # type: ignore
    tl = None  # type: ignore
    HAS_TRITON = False


# Exact openbmb/MiniCPM5-2B architectural constants (verified from HF config.json)
MINICPM5_2B_SPEC: Dict[str, Any] = {
    "model_id": "openbmb/MiniCPM5-2B",
    "architectures": ["LlamaForCausalLM"],
    "hidden_size": 2048,
    "intermediate_size": 6144,
    "num_hidden_layers": 42,
    "num_attention_heads": 16,
    "num_key_value_heads": 2,
    "head_dim": 128,
    "rms_norm_eps": 1e-6,
    "rope_theta": 5_000_000,
    "vocab_size": 130_560,
    "max_position_embeddings": 131_072,
    "torch_dtype": "bfloat16",
}

_KERNEL_HIT_COUNTS: Dict[str, int] = {"rms_norm": 0, "silu_and_mul": 0, "rotary": 0}
_ACTIVE_BACKENDS: Set[str] = set()
_ATEXIT_REGISTERED = False


def get_kernel_hit_counts() -> Dict[str, int]:
    return dict(_KERNEL_HIT_COUNTS)


def _flush_hit_log() -> None:
    hit_dir = os.environ.get("FLAGOS_HIT_LOG_DIR", "").strip()
    if not hit_dir:
        return
    total = sum(_KERNEL_HIT_COUNTS.values())
    if total <= 0:
        return
    try:
        p = Path(hit_dir)
        p.mkdir(parents=True, exist_ok=True)
        out_fp = p / f"hit_{os.getpid()}.json"
        payload = {
            "pid": os.getpid(),
            "total_hits": total,
            "hits": dict(_KERNEL_HIT_COUNTS),
            "backends": sorted(_ACTIVE_BACKENDS),
        }
        tmp_fp = out_fp.with_suffix(".json.tmp")
        tmp_fp.write_text(json.dumps(payload), encoding="utf-8")
        os.replace(tmp_fp, out_fp)
    except Exception:
        pass


def _record_kernel_hit(op_name: str, backend: str) -> None:
    global _ATEXIT_REGISTERED
    if not _ATEXIT_REGISTERED:
        _ATEXIT_REGISTERED = True
        atexit.register(_flush_hit_log)
    _KERNEL_HIT_COUNTS[op_name] = _KERNEL_HIT_COUNTS.get(op_name, 0) + 1
    _ACTIVE_BACKENDS.add(backend)
    total = sum(_KERNEL_HIT_COUNTS.values())
    # Flush early so SIGTERM'd vLLM EngineCore workers still leave verified hit markers
    if total in (1, 16, 128, 1024):
        _flush_hit_log()


# ---------------------------------------------------------------------------
# Reference PyTorch Implementations (Exact vLLM BF16 Semantics + CPU Fallback)
# ---------------------------------------------------------------------------

def ref_add_rms_norm(
    x: torch.Tensor,
    residual: Optional[torch.Tensor],
    weight: torch.Tensor,
    eps: float = 1e-6,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    orig_dtype = x.dtype
    if residual is not None:
        res_out = x + residual
        xf = res_out.float()
        rrms = torch.rsqrt(xf.pow(2).mean(dim=-1, keepdim=True) + eps)
        normed = (xf * rrms).to(orig_dtype) * weight
        return normed, res_out
    xf = x.float()
    rrms = torch.rsqrt(xf.pow(2).mean(dim=-1, keepdim=True) + eps)
    return (xf * rrms).to(orig_dtype) * weight


def ref_gate_up_silu_and_mul(gate_up: torch.Tensor) -> torch.Tensor:
    d = gate_up.shape[-1] // 2
    gate = gate_up[..., :d].float()
    up = gate_up[..., d:].float()
    out = (gate * torch.sigmoid(gate)) * up
    return out.to(gate_up.dtype)


def ref_neox_gqa_rope(
    query: torch.Tensor,
    key: Optional[torch.Tensor],
    cos: torch.Tensor,
    sin: torch.Tensor,
    position_ids: Optional[torch.Tensor] = None,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    """
    NeoX-style rotary embedding supporting arbitrary Q/KV head ratios (e.g. 16:2 GQA).
    query: [T, H_q, D], key: Optional[[T, H_k, D]], cos/sin: [max_pos, D//2] or [T, D//2].
    """
    if position_ids is not None:
        pos = position_ids.reshape(-1).long()
        c = cos.index_select(0, pos)
        s = sin.index_select(0, pos)
    else:
        t_len = query.shape[0]
        c = cos[:t_len]
        s = sin[:t_len]

    rot_dim = c.shape[-1] * 2
    half = rot_dim // 2
    c_u = c.unsqueeze(1).float()  # [T, 1, half]
    s_u = s.unsqueeze(1).float()

    def _rot(t: torch.Tensor) -> torch.Tensor:
        t_rot = t[..., :rot_dim].float()
        x1 = t_rot[..., :half]
        x2 = t_rot[..., half:rot_dim]
        o1 = x1 * c_u - x2 * s_u
        o2 = x2 * c_u + x1 * s_u
        rot = torch.cat([o1, o2], dim=-1).to(t.dtype)
        if rot_dim == t.shape[-1]:
            return rot
        return torch.cat([rot, t[..., rot_dim:]], dim=-1)

    q_out = _rot(query)
    if key is None:
        return q_out
    return q_out, _rot(key)


def _apply_ref_rope_respecting_inplace(
    query: torch.Tensor,
    key: Optional[torch.Tensor],
    cos: torch.Tensor,
    sin: torch.Tensor,
    position_ids: Optional[torch.Tensor],
    inplace: bool,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    res = ref_neox_gqa_rope(query, key, cos, sin, position_ids)
    if inplace:
        if key is None:
            query.copy_(res)  # type: ignore[arg-type]
            return query
        q_r, k_r = res  # type: ignore[misc]
        query.copy_(q_r)
        key.copy_(k_r)
        return query, key
    return res


# ---------------------------------------------------------------------------
# Portable Triton Kernels (64-bit `tl.int64` Pointer Safe, Multi-Chip Portable)
# ---------------------------------------------------------------------------

if HAS_TRITON:

    @triton.jit
    def _fused_inplace_add_rms_norm_kernel(
        out_ptr,
        x_ptr,
        res_ptr,
        w_ptr,
        out_row_stride,
        x_row_stride,
        res_row_stride,
        N,
        eps,
        HAS_RESIDUAL: tl.constexpr,
        BLOCK_N: tl.constexpr,
    ):
        row = tl.program_id(0).to(tl.int64)
        cols = tl.arange(0, BLOCK_N).to(tl.int64)
        mask = cols < N

        x_val = tl.load(x_ptr + row * x_row_stride + cols, mask=mask, other=0.0).to(tl.float32)
        if HAS_RESIDUAL:
            r_val = tl.load(res_ptr + row * res_row_stride + cols, mask=mask, other=0.0).to(tl.float32)
            x_val = x_val + r_val
            tl.store(res_ptr + row * res_row_stride + cols, x_val.to(res_ptr.dtype.element_ty), mask=mask)

        var = tl.sum(x_val * x_val, axis=0) / N
        rrms = tl.math.rsqrt(var + eps)
        # Match exact vLLM native BF16/FP16 rounding: cast (x * rrms) to input dtype before * weight
        x_normed = (x_val * rrms).to(x_ptr.dtype.element_ty)
        w_val = tl.load(w_ptr + cols, mask=mask, other=0.0)
        y = x_normed * w_val
        tl.store(out_ptr + row * out_row_stride + cols, y, mask=mask)

    @triton.autotune(
        configs=[
            triton.Config({"BLOCK_N": 512}, num_warps=4, num_stages=2),
            triton.Config({"BLOCK_N": 1024}, num_warps=4, num_stages=3),
            triton.Config({"BLOCK_N": 1024}, num_warps=8, num_stages=3),
            triton.Config({"BLOCK_N": 2048}, num_warps=8, num_stages=3),
        ],
        key=["D"],
    )
    @triton.jit
    def _fused_gate_up_silu_mul_kernel(
        out_ptr,
        gate_up_ptr,
        out_row_stride,
        gu_row_stride,
        D,
        BLOCK_N: tl.constexpr,
    ):
        row = tl.program_id(0).to(tl.int64)
        col_blk = tl.program_id(1).to(tl.int64)
        cols = col_blk * BLOCK_N + tl.arange(0, BLOCK_N).to(tl.int64)
        mask = cols < D

        base_gu = gate_up_ptr + row * gu_row_stride
        gate = tl.load(base_gu + cols, mask=mask, other=0.0).to(tl.float32)
        up = tl.load(base_gu + D + cols, mask=mask, other=0.0).to(tl.float32)
        silu_gate = gate * tl.sigmoid(gate)
        out = (silu_gate * up).to(out_ptr.dtype.element_ty)
        tl.store(out_ptr + row * out_row_stride + cols, out, mask=mask)

    @triton.jit
    def _fused_strided_gqa_rope_kernel(
        q_ptr,
        k_ptr,
        cos_ptr,
        sin_ptr,
        pos_ptr,
        q_stride_t,
        q_stride_h,
        k_stride_t,
        k_stride_h,
        cos_stride_t,
        H_Q: tl.constexpr,
        H_K: tl.constexpr,
        HALF_D: tl.constexpr,
        HAS_K: tl.constexpr,
        HAS_POS: tl.constexpr,
    ):
        pid_t = tl.program_id(0).to(tl.int64)
        pid_h = tl.program_id(1).to(tl.int64)  # 0 .. H_Q + H_K - 1

        pos_idx = tl.load(pos_ptr + pid_t).to(tl.int64) if HAS_POS else pid_t
        offs = tl.arange(0, HALF_D).to(tl.int64)
        c = tl.load(cos_ptr + pos_idx * cos_stride_t + offs).to(tl.float32)
        s = tl.load(sin_ptr + pos_idx * cos_stride_t + offs).to(tl.float32)

        if pid_h < H_Q:
            base = q_ptr + pid_t * q_stride_t + pid_h * q_stride_h
            x1 = tl.load(base + offs).to(tl.float32)
            x2 = tl.load(base + HALF_D + offs).to(tl.float32)
            tl.store(base + offs, (x1 * c - x2 * s).to(q_ptr.dtype.element_ty))
            tl.store(base + HALF_D + offs, (x2 * c + x1 * s).to(q_ptr.dtype.element_ty))
        elif HAS_K:
            kh = pid_h - H_Q
            if kh < H_K:
                base_k = k_ptr + pid_t * k_stride_t + kh * k_stride_h
                k1 = tl.load(base_k + offs).to(tl.float32)
                k2 = tl.load(base_k + HALF_D + offs).to(tl.float32)
                tl.store(base_k + offs, (k1 * c - k2 * s).to(k_ptr.dtype.element_ty))
                tl.store(base_k + HALF_D + offs, (k2 * c + k1 * s).to(k_ptr.dtype.element_ty))


# ---------------------------------------------------------------------------
# Public Dispatch Wrappers (Auto-Select Triton on GPU, Reference on CPU)
# ---------------------------------------------------------------------------

def fused_inplace_add_rms_norm(
    x: torch.Tensor,
    residual: Optional[torch.Tensor],
    weight: torch.Tensor,
    eps: float = 1e-6,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    if not (HAS_TRITON and getattr(x, "is_cuda", False)):
        if residual is not None:
            normed, res_updated = ref_add_rms_norm(x, residual, weight, eps)
            residual.copy_(res_updated)
            return normed, residual
        return ref_add_rms_norm(x, None, weight, eps)

    orig_shape = x.shape
    n_cols = orig_shape[-1]
    x_2d = x.contiguous().view(-1, n_cols)
    n_rows = x_2d.shape[0]
    out_2d = torch.empty_like(x_2d)
    block_n = triton.next_power_of_2(n_cols)
    num_warps = 8 if block_n >= 2048 else 4

    if residual is not None:
        res_2d = residual.view(-1, n_cols)
        _fused_inplace_add_rms_norm_kernel[(n_rows,)](
            out_2d,
            x_2d,
            res_2d,
            weight,
            out_2d.stride(0),
            x_2d.stride(0),
            res_2d.stride(0),
            n_cols,
            eps,
            HAS_RESIDUAL=True,
            BLOCK_N=block_n,
            num_warps=num_warps,
        )
        return out_2d.view(orig_shape), residual

    _fused_inplace_add_rms_norm_kernel[(n_rows,)](
        out_2d,
        x_2d,
        x_2d,
        weight,
        out_2d.stride(0),
        x_2d.stride(0),
        x_2d.stride(0),
        n_cols,
        eps,
        HAS_RESIDUAL=False,
        BLOCK_N=block_n,
        num_warps=num_warps,
    )
    return out_2d.view(orig_shape)


def fused_gate_up_silu_and_mul(gate_up: torch.Tensor) -> torch.Tensor:
    if not (HAS_TRITON and getattr(gate_up, "is_cuda", False)):
        return ref_gate_up_silu_and_mul(gate_up)

    orig_shape = gate_up.shape
    two_d = orig_shape[-1]
    d = two_d // 2
    gu_2d = gate_up.contiguous().view(-1, two_d)
    n_rows = gu_2d.shape[0]
    out_2d = torch.empty((n_rows, d), device=gate_up.device, dtype=gate_up.dtype)

    grid = lambda meta: (n_rows, triton.cdiv(d, meta["BLOCK_N"]))
    _fused_gate_up_silu_mul_kernel[grid](
        out_2d,
        gu_2d,
        out_2d.stride(0),
        gu_2d.stride(0),
        d,
    )
    return out_2d.view(*orig_shape[:-1], d)


def fused_strided_gqa_rope(
    query: torch.Tensor,
    key: Optional[torch.Tensor],
    cos: torch.Tensor,
    sin: torch.Tensor,
    position_ids: Optional[torch.Tensor] = None,
    inplace: bool = True,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    if not (HAS_TRITON and getattr(query, "is_cuda", False) and query.stride(-1) == 1):
        return _apply_ref_rope_respecting_inplace(query, key, cos, sin, position_ids, inplace)

    orig_q_shape = query.shape
    head_dim = orig_q_shape[-1]
    half_d = cos.shape[-1]
    if half_d * 2 != head_dim or (half_d & (half_d - 1)) != 0:
        return _apply_ref_rope_respecting_inplace(query, key, cos, sin, position_ids, inplace)

    q_work = query if inplace else query.clone()
    k_work = (key if inplace else key.clone()) if key is not None else None

    q_3d = q_work.view(-1, orig_q_shape[-2], head_dim)
    n_tokens, h_q, _ = q_3d.shape
    has_k = k_work is not None
    if has_k:
        assert k_work is not None
        k_3d = k_work.view(n_tokens, -1, head_dim)
        h_k = k_3d.shape[1]
        k_stride_t, k_stride_h = k_3d.stride(0), k_3d.stride(1)
    else:
        k_3d = q_3d
        h_k = 0
        k_stride_t, k_stride_h = 0, 0

    has_pos = position_ids is not None
    pos_1d = position_ids.reshape(-1).contiguous() if has_pos else q_3d[:, 0, 0]

    grid = (n_tokens, h_q + h_k)
    _fused_strided_gqa_rope_kernel[grid](
        q_3d,
        k_3d,
        cos,
        sin,
        pos_1d,
        q_3d.stride(0),
        q_3d.stride(1),
        k_stride_t,
        k_stride_h,
        cos.stride(0),
        H_Q=h_q,
        H_K=max(1, h_k),
        HALF_D=half_d,
        HAS_K=has_k,
        HAS_POS=has_pos,
        num_warps=2 if half_d <= 64 else 4,
    )
    if key is None:
        return q_work
    assert k_work is not None
    return q_work, k_work


# ---------------------------------------------------------------------------
# Child-Worker & Multi-Backend Patcher (`vllm_fl` + Native `vllm` Layers)
# ---------------------------------------------------------------------------

def _patch_vllm_fl_modules() -> bool:
    patched_any = False
    try:
        import vllm_fl.dispatch.backends.flaggems.impl.normalization as fl_norm  # type: ignore

        if not getattr(fl_norm, "_flagos_minicpm5_patched", False):
            def _patched_rms_norm(obj: Any, x: Any, residual: Any = None) -> Any:
                _record_kernel_hit("rms_norm", "vllm_fl")
                return fused_inplace_add_rms_norm(x, residual, obj.weight, obj.variance_epsilon)

            fl_norm.rms_norm_flaggems = _patched_rms_norm
            fl_norm._flagos_minicpm5_patched = True
        patched_any = True
    except ImportError:
        pass

    try:
        import vllm_fl.dispatch.backends.flaggems.impl.activation as fl_act  # type: ignore

        if not getattr(fl_act, "_flagos_minicpm5_patched", False):
            def _patched_silu_and_mul(obj: Any, x: Any) -> Any:
                _record_kernel_hit("silu_and_mul", "vllm_fl")
                return fused_gate_up_silu_and_mul(x)

            fl_act.silu_and_mul_flaggems = _patched_silu_and_mul
            fl_act._flagos_minicpm5_patched = True
        patched_any = True
    except ImportError:
        pass

    try:
        import vllm_fl.dispatch.backends.flaggems.impl.rotary as fl_rot  # type: ignore

        if not getattr(fl_rot, "_flagos_minicpm5_patched", False):
            orig_rope = fl_rot.rotary_embedding_flaggems

            def _patched_rotary(
                obj: Any,
                query: Any,
                key: Any,
                cos: Any,
                sin: Any,
                position_ids: Any,
                rotary_interleaved: bool = False,
                inplace: bool = True,
            ) -> Any:
                if not rotary_interleaved and cos.shape[-1] * 2 == query.shape[-1]:
                    _record_kernel_hit("rotary", "vllm_fl")
                    return fused_strided_gqa_rope(query, key, cos, sin, position_ids=position_ids, inplace=inplace)
                return orig_rope(obj, query, key, cos, sin, position_ids, rotary_interleaved, inplace)

            fl_rot.rotary_embedding_flaggems = _patched_rotary
            fl_rot._flagos_minicpm5_patched = True
        patched_any = True
    except ImportError:
        pass

    return patched_any


def _patch_vllm_native_layers() -> bool:
    """
    Hook `vllm.model_executor.layers.{layernorm,activation,rotary_embedding}` directly so child
    `vllm` CLI & `EngineCore` workers execute our Triton kernels on CUDA even when `vllm_fl` is absent.
    """
    patched_any = False

    if "vllm.model_executor.layers.layernorm" in sys.modules:
        ln_mod = sys.modules["vllm.model_executor.layers.layernorm"]
        rms_cls = getattr(ln_mod, "RMSNorm", None)
        if rms_cls is not None and not getattr(rms_cls, "_flagos_minicpm5_patched", False):
            orig_fwd_cuda = getattr(rms_cls, "forward_cuda", None) or getattr(rms_cls, "forward", None)
            if orig_fwd_cuda is not None:
                def _rms_forward_cuda(self: Any, x: Any, residual: Any = None) -> Any:
                    if getattr(self, "variance_size_override", None) is not None or not getattr(self, "has_weight", True):
                        return orig_fwd_cuda(self, x, residual)
                    _record_kernel_hit("rms_norm", "vllm_layers")
                    return fused_inplace_add_rms_norm(x, residual, self.weight, self.variance_epsilon)

                if hasattr(rms_cls, "forward_cuda"):
                    rms_cls.forward_cuda = _rms_forward_cuda
                else:
                    rms_cls.forward = _rms_forward_cuda
                rms_cls._flagos_minicpm5_patched = True
                patched_any = True

    if "vllm.model_executor.layers.activation" in sys.modules:
        act_mod = sys.modules["vllm.model_executor.layers.activation"]
        silu_cls = getattr(act_mod, "SiluAndMul", None)
        if silu_cls is not None and not getattr(silu_cls, "_flagos_minicpm5_patched", False):
            if hasattr(silu_cls, "forward_cuda") or hasattr(silu_cls, "forward"):
                def _silu_forward_cuda(self: Any, x: Any) -> Any:
                    _record_kernel_hit("silu_and_mul", "vllm_layers")
                    return fused_gate_up_silu_and_mul(x)

                if hasattr(silu_cls, "forward_cuda"):
                    silu_cls.forward_cuda = _silu_forward_cuda
                else:
                    silu_cls.forward = _silu_forward_cuda
                silu_cls._flagos_minicpm5_patched = True
                patched_any = True

    if "vllm.model_executor.layers.rotary_embedding" in sys.modules:
        rot_mod = sys.modules["vllm.model_executor.layers.rotary_embedding"]
        rot_cls = getattr(rot_mod, "RotaryEmbedding", None)
        if rot_cls is not None and not getattr(rot_cls, "_flagos_minicpm5_patched", False):
            orig_rot_cuda = getattr(rot_cls, "forward_cuda", None) or getattr(rot_cls, "forward", None)
            if orig_rot_cuda is not None:
                def _rotary_forward_cuda(
                    self: Any,
                    positions: Any,
                    query: Any,
                    key: Any = None,
                    offsets: Any = None,
                ) -> Any:
                    head_size = int(getattr(self, "head_size", 0) or 0)
                    rot_dim = int(getattr(self, "rotary_dim", head_size) or 0)
                    if (
                        offsets is None
                        and getattr(self, "is_neox_style", True)
                        and head_size > 0
                        and rot_dim == head_size
                        and hasattr(self, "cos_sin_cache")
                    ):
                        cache = self.cos_sin_cache
                        if hasattr(cache, "device") and hasattr(query, "device") and cache.device != query.device:
                            cache = cache.to(query.device)
                            self.cos_sin_cache = cache
                        cos, sin = cache.chunk(2, dim=-1)
                        q_3d = query.view(-1, query.shape[-1] // head_size, head_size) if query.shape[-1] != head_size else query
                        k_3d = (
                            (key.view(-1, key.shape[-1] // head_size, head_size) if key.shape[-1] != head_size else key)
                            if key is not None
                            else None
                        )
                        if q_3d.shape[0] == positions.numel():
                            _record_kernel_hit("rotary", "vllm_layers")
                            fused_strided_gqa_rope(q_3d, k_3d, cos, sin, position_ids=positions, inplace=True)
                            return query, key
                    return orig_rot_cuda(self, positions, query, key, offsets)

                if hasattr(rot_cls, "forward_cuda"):
                    rot_cls.forward_cuda = _rotary_forward_cuda
                else:
                    rot_cls.forward = _rotary_forward_cuda
                rot_cls._flagos_minicpm5_patched = True
                patched_any = True

    return patched_any


def patch_vllm_fl_for_minicpm5() -> bool:
    """
    Live-bind our 3 optimized Triton operators into BOTH `vllm_fl.dispatch.backends.flaggems.impl`
    AND `vllm.model_executor.layers.{layernorm,activation,rotary_embedding}` (importing them if installed).
    """
    fl_ok = _patch_vllm_fl_modules()
    for mod_name in (
        "vllm.model_executor.layers.layernorm",
        "vllm.model_executor.layers.activation",
        "vllm.model_executor.layers.rotary_embedding",
    ):
        try:
            __import__(mod_name)
        except ImportError:
            continue
    vllm_ok = _patch_vllm_native_layers()
    return bool(fl_ok or vllm_ok)


_WATCHED_MODULES = frozenset({
    "vllm.model_executor.layers.layernorm",
    "vllm.model_executor.layers.activation",
    "vllm.model_executor.layers.rotary_embedding",
    "vllm_fl.dispatch.backends.flaggems.impl.normalization",
    "vllm_fl.dispatch.backends.flaggems.impl.activation",
    "vllm_fl.dispatch.backends.flaggems.impl.rotary",
})


class _PostImportPatchLoader(importlib.abc.Loader):
    def __init__(self, wrapped_loader: importlib.abc.Loader) -> None:
        self._wrapped = wrapped_loader

    def create_module(self, spec: importlib.machinery.ModuleSpec) -> Any:
        if hasattr(self._wrapped, "create_module"):
            return self._wrapped.create_module(spec)
        return None

    def exec_module(self, module: Any) -> None:
        self._wrapped.exec_module(module)
        name = getattr(module, "__name__", "")
        if name.startswith("vllm_fl."):
            _patch_vllm_fl_modules()
        elif name.startswith("vllm."):
            _patch_vllm_native_layers()


class _FlagOSAutoPatchFinder(importlib.abc.MetaPathFinder):
    """Intercepts target `vllm` / `vllm_fl` layer modules on import inside child worker processes."""

    def __init__(self) -> None:
        self._in_progress: Set[str] = set()

    def find_spec(
        self,
        fullname: str,
        path: Optional[Any],
        target: Optional[Any] = None,
    ) -> Optional[importlib.machinery.ModuleSpec]:
        if fullname not in _WATCHED_MODULES or fullname in self._in_progress:
            return None
        self._in_progress.add(fullname)
        try:
            for finder in sys.meta_path:
                if finder is self or not hasattr(finder, "find_spec"):
                    continue
                spec = finder.find_spec(fullname, path, target)
                if spec is not None and spec.loader is not None:
                    spec.loader = _PostImportPatchLoader(spec.loader)
                    return spec
            return None
        finally:
            self._in_progress.discard(fullname)


_HOOK_INSTALLED = False


def install_auto_patch_import_hook() -> None:
    """Called by `sitecustomize.py` in every child `vllm` CLI & `EngineCore` worker when `FLAGOS_PATCH_ENABLE=1`."""
    global _HOOK_INSTALLED
    if _HOOK_INSTALLED:
        return
    _HOOK_INSTALLED = True
    sys.meta_path.insert(0, _FlagOSAutoPatchFinder())
    # Also patch immediately if any watched module was already imported
    _patch_vllm_fl_modules()
    _patch_vllm_native_layers()
