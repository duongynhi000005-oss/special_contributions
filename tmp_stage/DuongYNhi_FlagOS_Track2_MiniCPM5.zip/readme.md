# FlagOS Open Computing Global Challenge — Track 2 Submission
## MiniCPM5-2B Full-Stack Inference Throughput Optimization (`bfloat16`)

### 1. Overview & Compliance
- **Target Model**: `openbmb/MiniCPM5-2B` (`LlamaForCausalLM`, `42` layers, `hidden_size=2048`, `intermediate_size=6144`, `16:2` GQA, `head_dim=128`, `rope_theta=5,000,000`, `vocab_size=130,560`)
- **Fairness Compliance**: Strict `bfloat16` full precision (**NO** quantization, **NO** speculative decoding, **NO** benchmark script tampering), enforcing `HuggingFaceH4/MATH-500 >= 0.95` greedy accuracy retention.
- **Cross-Chip Portability**: Pure 64-bit (`tl.int64` pointer-safe) Triton kernels (`0` vendor-locked PTX inline assembly), portable across NVIDIA A100, **Iluvatar CoreX BI-V150 (64GB)**, and **MetaX Xiyun C500 (64GB)** via `FlagGems`, `vllm-plugin-FL`, and native `vLLM` child-worker `sitecustomize.py` injection.

### 2. Core Kernel & Child-Worker Dispatch Optimizations
1. **`fused_inplace_add_rms_norm`**: Eliminates separate residual-addition HBM traffic across all 84 norm sites per token while matching exact vLLM BF16 weight-multiply rounding `(x * rrms).to(bf16) * weight`.
2. **`fused_gate_up_silu_and_mul`**: Coalesced single-tensor `[T, 12288]` autotuned SwiGLU kernel eliminating non-contiguous slice stride overhead.
3. **`fused_strided_gqa_rope`**: Single-launch asymmetric `16:2` GQA NeoX RoPE kernel eliminating 3 `.contiguous()` copies, `torch.arange` allocations, and dummy K launches.
4. **Child-Process `sitecustomize.py` Auto-Hook**: Automatically patches spawned `vllm` CLI and `EngineCore` subprocesses when `FLAGOS_PATCH_ENABLE=1` and records verified per-PID kernel hit counters.

### 3. Reproduction Instructions
```bash
pip install torch triton vllm flag-gems datasets
python3 benchmarks/flagos_track2_minicpm5_a100_ready.py --work-dir ./out --no-auto-disconnect
```
